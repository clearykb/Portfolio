public class Task06 {
    public static void main(String[] args) {
        final int ROW = 5;

        for(int row = 0; row<ROW; row++) {

            for(int col = ROW; col>row; col--) {
                System.out.print("* ");
            }
            System.out.println(" ");
        }
    }
}