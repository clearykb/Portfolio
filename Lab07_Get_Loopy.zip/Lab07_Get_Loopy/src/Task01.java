public class Task01 {
    public static void main(String[] args) {
        for (int counter=0; counter<=30; counter++) {
            System.out.println(counter);
        }
    }
}
