public class Task04 {

    public static void main(String[] args) {

        for (int x = 10; x >= 0; x -= 2) {

            System.out.println(x);

        }

    }

}