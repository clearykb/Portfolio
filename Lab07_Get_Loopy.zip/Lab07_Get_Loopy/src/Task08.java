import java.util.Random;
import java.util.Scanner;

public class Task08 {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);
        String playAgain;

        do {
            int die1, die2, die3, rollNumber = 0;
            int sum;

            System.out.printf("%-10s %-10s %-10s %-10s %-10s%n", "Roll", "Die 1", "Die 2", "Die 3", "Sum");
            System.out.println("-------------------------------------------------");
            do {
                rollNumber++;

                die1 = random.nextInt(6) + 1;
                die2 = random.nextInt(6) + 1;
                die3 = random.nextInt(6) + 1;

                sum = die1 + die2 + die3;

                System.out.printf("%-10d %-10d %-10d %-10d %-10d%n", rollNumber, die1, die2, die3, sum);


            } while (die1 != die2 || die2 != die3);

            System.out.print("Do you want to continue? (y/n)");
            playAgain = scanner.next();

        } while (playAgain.equalsIgnoreCase("y"));

        scanner.close();

    }
}
