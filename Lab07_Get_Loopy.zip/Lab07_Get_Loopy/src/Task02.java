public class Task02 {
    public static void main(String[] args) {
        for (int counter=30; counter>=0; counter--) {
            System.out.println(counter);
        }
    }
}
