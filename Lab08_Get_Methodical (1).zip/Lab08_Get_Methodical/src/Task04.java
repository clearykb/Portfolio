import java.util.Scanner;

public class Task04 {

    public static void main(String[] args) {
        Scanner pipe = new Scanner(System.in);
        double totalCost = 0.0;
        boolean hasMoreItems;

        do {
            double price = SafeInput.getRangedDouble(pipe, "Enter the price of the item ($0.50 - $10.00)", 0.50, 10.00);
            totalCost += price;
            hasMoreItems = SafeInput.getYNConfirm(pipe, "Do you have more items?");
        } while (hasMoreItems);

        System.out.printf("Total cost: $%.2f\n", totalCost);
        pipe.close();
    }
}