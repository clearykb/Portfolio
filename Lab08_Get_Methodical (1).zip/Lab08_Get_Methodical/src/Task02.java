import java.util.Scanner;

public class Task02 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int number = SafeInput.getInt(in, "Enter your favourite integer");
        System.out.println("You entered: " + number);

        double salary = SafeInput.getDouble(in, "Enter your favourite double");
        System.out.println("You entered " + salary);

    }


}

