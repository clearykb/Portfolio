import java.util.Scanner;

public class Task05 {

    public static void main(String[] args) {
        Scanner pipe = new Scanner(System.in);

        String ssn = SafeInput.getRegExString(pipe, "Enter your SSN (###-##-####)", "^\\d{3}-\\d{2}-\\d{4}$");
        System.out.println("SSN entered: " + ssn);

        String mNumber = SafeInput.getRegExString(pipe, "Enter your UC M number (M#####)", "^(M|m)\\d{5}$");
        System.out.println("M number entered: " + mNumber);

        String menuChoice = SafeInput.getRegExString(pipe, "Enter a menu choice (O=Open, S=Save, V=View, Q=Quit)", "^[OoSsVvQq]$");
        System.out.println("Menu choice entered: " + menuChoice);

        pipe.close();
    }
}