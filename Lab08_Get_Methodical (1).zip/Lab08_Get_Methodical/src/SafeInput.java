import java.awt.color.ICC_ColorSpace;
import java.util.Scanner;
import java.util.regex.Pattern;

public class SafeInput {

    public static String getNonZeroLenString(Scanner pipe, String prompt) {
        String retString = ""; // Set this to zero length. Loop runs until it isn't

        do {
            System.out.print("\n" + prompt + ": "); // show prompt add space
            retString = pipe.nextLine();
        } while (retString.length() == 0);

        return retString;

    }

    public static int getInt(Scanner pipe, String prompt) {
        int retVal = 0;
        boolean validInput = false;

        do {
            System.out.println("\n" + prompt + ": ");

            if (pipe.hasNextInt()) {
                retVal = pipe.nextInt();
                pipe.nextLine();
                validInput = true;
            } else {
                String trash = pipe.nextLine();
                System.out.println("Error: '" + trash + "' is not a valid integer. Please try again.");
            }
        } while (!validInput);

        return retVal;
    }

    public static double getDouble(Scanner pipe, String prompt) {
        double retVal = 0.0;
        boolean validInput = false;

        do {
            System.out.println("\n" + prompt + ": ");

            if (pipe.hasNextDouble()) {
                retVal = pipe.nextDouble();
                pipe.nextLine();
                validInput = true;
            } else {
                String trash = pipe.nextLine();
                System.out.println("Error: '" + trash + "' is not a valid double. Please try again.");
            }
        } while (!validInput);

        return retVal;
    }

    public static int getRangedInt(Scanner pipe, String prompt, int low, int high) {
        int retVal = 0;
        boolean validInput = false;

        do {
            System.out.print("\n" + prompt + " [" + low + " - " + high + "]: ");

            if (pipe.hasNextInt()) {
                retVal = pipe.nextInt();
                pipe.nextLine();

                if (retVal >= low && retVal <= high) {
                    validInput = true;
                } else {
                    System.out.println("Error: Input must be between " + low + " and " + high + ". Please try again.");
                }
            } else {
                String trash = pipe.nextLine();
                System.out.println("Error: '" + trash + "' is not a valid integer. Please try again.");
            }
        } while (!validInput);

        return retVal;

    }

    public static double getRangedDouble(Scanner pipe, String prompt, double low, double high) {
        double retVal = 0.0;
        boolean validInput = false;

        do {
            System.out.print("\n" + prompt + " [" + low + " - " + high + "]: ");

            if (pipe.hasNextDouble()) {
                retVal = pipe.nextDouble();
                pipe.nextLine();

                if (retVal >= low && retVal <= high) {
                    validInput = true;
                } else {
                    System.out.println("Error: Input must be between " + low + " and " + high + ". Please try again.");
                }
            } else {
                String trash = pipe.nextLine();
                System.out.println("Error: '" + trash + "' is not a valid double. Please try again.");
            }
        } while (!validInput);

        return retVal;

    }

    public static boolean getYNConfirm(Scanner pipe, String prompt) {
        String response;
        boolean validInput = false;

        do {
            System.out.print("\n" + prompt + " (Y/N): ");

            response = pipe.nextLine().trim();

            if (response.equalsIgnoreCase("y")) {
                return true;
            } else if (response.equalsIgnoreCase("n")) {
                return false;
            } else {
                System.out.println("Error: Please enter 'Y' for yes or 'N' for no.");
            }
        } while (!validInput);

        return validInput;
    }

    public static String getRegExString(Scanner pipe, String prompt, String regEx) {
        String input;
        boolean validInput = false;
        Pattern pattern = Pattern.compile(regEx);

        do {
            System.out.print("\n" + prompt + ": ");
            input = pipe.nextLine();

            if (pattern.matcher(input).matches()) {
                return input;
            } else {
                System.out.println("Error: Input does not match the required pattern. Please try again.");
            }
        } while (!validInput);

        return input;
    }
    public static void prettyHeader(String msg) {
        int totalWidth = 60;
        int msgWidth = msg.length();
        int paddingWidth = (totalWidth - msgWidth - 6) / 2;

        for (int i = 0; i < totalWidth; i++) {
            System.out.print("*");
        }
        System.out.println();

        for (int i = 0; i < 3; i++) {
            System.out.print("*");
        }
        for (int i = 0; i < paddingWidth; i++) {
            System.out.print(" ");
        }
        System.out.print(msg);
        for (int i = 0; i < paddingWidth; i++) {
            System.out.print(" ");
        }

        if ((totalWidth - msgWidth - 6) % 2 != 0) {
            System.out.print(" ");
        }

        for (int i = 0; i < 3; i++) {
            System.out.print("*");
        }
        System.out.println();

        for (int i = 0; i < totalWidth; i++) {
            System.out.print("*");
        }
        System.out.println();
    }


    }




