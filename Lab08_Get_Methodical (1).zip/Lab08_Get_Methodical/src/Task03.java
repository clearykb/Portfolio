import java.util.Scanner;

public class Task03 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int year = SafeInput.getRangedInt(in, "Enter your year", 1950, 2015);
        System.out.println("You entered: " + year);

        int month = SafeInput.getRangedInt(in, "Enter your month", 1, 12);
        System.out.println("You entered: " + month);
        if(month == 10) {
            SafeInput.getRangedInt(in, "Enter your day of birth", 1, 31);
        }
        else if(month == 2) {
            SafeInput.getRangedInt(in, "Enter your day of birth", 1, 29);
        }
        else {
            int day = SafeInput.getRangedInt(in, "Enter your day of birth", 1, 30);
            System.out.println("You entered: " + day);
        }


        int hour = SafeInput.getRangedInt(in, "Enter your hour of birth", 1, 24);
        System.out.println("You entered: " + hour);

        int minutes = SafeInput.getRangedInt(in, "Enter your minute of birth", 1, 59);
        System.out.println("You entered: " + minutes);


    }
}
