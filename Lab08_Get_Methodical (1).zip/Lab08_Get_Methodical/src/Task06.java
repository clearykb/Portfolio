import java.util.Scanner;

public class Task06 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("Enter a header: ");
        String input = in.nextLine();

        SafeInput.prettyHeader(input);
    }
}