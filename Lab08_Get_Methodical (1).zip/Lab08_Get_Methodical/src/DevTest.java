import java.util.Scanner;

public class DevTest {
    public static void main(String[] args) {
        Scanner in = new Scanner (System.in);

        String result = SafeInput.getNonZeroLenString(in, "Enter your name");
        System.out.println("You entered: " + result);

        int number = SafeInput.getInt(in, "Enter an integer");
        System.out.println("You entered: " + number);

        double salary = SafeInput.getDouble(in, "Enter your salary");
        System.out.println("You entered " + salary);

        int age = SafeInput.getRangedInt(in, "Enter your age", 18, 35);
        System.out.println("You entered: " + age);

        double salary1 = SafeInput.getRangedDouble(in, "Enter your salary", 30000.0, 100000.0);

        boolean confirm = SafeInput.getYNConfirm(in, "Do you want to proceed?");
        System.out.println("You entered: " + (confirm ? "Yes" : "No"));

        String email = SafeInput.getRegExString(in, "Enter a valid email address", "^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
        System.out.println("You entered: " + email);
        in.close();
    }
}